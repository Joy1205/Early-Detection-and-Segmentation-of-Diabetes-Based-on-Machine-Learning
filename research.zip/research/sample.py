import tensorflow as tf
from flask import Flask,render_template,request,session
from DBConnection import Db
import numpy as np
import pandas
app=Flask(__name__)
app.secret_key="abcd"

@app.route('/')
@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/loginpage',methods=['POST'])
def loginpage(return_render=None):
    uname=request.form["txt_uname"]
    pwd=request.form["txt_password"]
    dbcon=Db()
    qry="SELECT * FROM login WHERE username='"+uname+"' AND PASSWORD='"+pwd+"';"
    res=dbcon.selectOne(qry)
    if res is None:
        return "<script>alert('Invalid username or password'>;window.location='/'</script>"
    else:
        if res['usertype']=='user':
             session['lid']=res['loginid']
             return render_template('userpanel.html')

        elif res['usertype']=='admin':
            return render_template('adminpanel.html')
        elif res['usertype']=='doctor':
            return render_template('doctor/doct_home.html')
        else:
            return "<script>alert('invalid user or password'>;window.location='/login'</script>"
    


@app.route('/signup')
def signup():
    return render_template('signup.html')
@app.route('/signuppage',methods=['POST'])
def signuppage():
    fname=request.form["txt_fname"]
    lname=request.form["txt_lname"]
    gender=request.form["txt_gender"]
    dob= request.form["txt_dob"]
    email= request.form["txt_uname"]
    phone= request.form["txt_phone"]
    file = request.files["txt_file"]
    pwd= request.form["txt_password"]
    confirm= request.form["txt_confirm"]
    file.save("I:\\Research\\research\\static\\userreg\\" +file.filename)
    filename="/static/userreg/" +file.filename
    dbcon=Db()
    qry="INSERT INTO login(username,PASSWORD,usertype)VALUES('"+email+"','"+pwd+"','user');"
    res=dbcon.insert(qry)
    qr2="INSERT INTO userreg(NAME,gender,dob,photo,email,phone,loginid)VALUES('"+fname+lname+"','"+gender+"','"+dob+"','"+ filename+"','"+email+"','"+phone+"','"+str(res)+"')"
    dbcon.insert(qr2)
    return '''<script>alert("success");window.location='/'</script>'''

@app.route('/signuppagedoctor',methods=['POST'])
def signuppagedoctor():
    fname=request.form["txt_fname"]
    lname=request.form["txt_lname"]
    gender=request.form["txt_gender"]
    dob= request.form["txt_dob"]
    email= request.form["txt_uname"]
    phone= request.form["txt_phone"]
    file = request.files["txt_file"]
    pwd= request.form["txt_password"]
    confirm= request.form["txt_confirm"]
    qualification= request.form["txt_q"]
    experience= request.form["txt_e"]
    confirm= request.form["txt_confirm"]
    file.save("I:\\Research\\research\\static\\userreg\\" +file.filename)
    filename="/static/userreg/" +file.filename
    dbcon=Db()
    qry="INSERT INTO login(username,PASSWORD,usertype)VALUES('"+email+"','"+pwd+"','doctor');"
    res=dbcon.insert(qry)
    qr2="INSERT INTO doctors(NAME,gender,dob,photo,email,phone,loginid,experience,qualification)VALUES('"+fname+lname+"','"+gender+"','"+dob+"','"+ filename+"','"+email+"','"+phone+"','"+str(res)+"','"+experience+"','"+qualification+"')"
    dbcon.insert(qr2)
    return '''<script>alert("Account created successfully");window.location='/'</script>'''


@app.route('/userprofile')
def userprofile():
    dbcon=Db()
    qry="SELECT * FROM userreg WHERE loginid='"+str(session['lid'])+"'"
    res=dbcon.selectOne(qry)
    return render_template('userviewprofile.html',data=res)


@app.route('/editprofile')
def editprofile():
    dbcon = Db()
    qry = "SELECT * FROM userreg WHERE loginid='" + str(session['lid']) + "'"
    res = dbcon.selectOne(qry)
    return render_template('editprofile.html',data=res)
@app.route('/editpage',methods=['POST'])
def editpage():
    fname=request.form["txt_fname"]
    lname=request.form["txt_lname"]
    gender=request.form["txt_gender"]
    dob= request.form["txt_dob"]
    uname= request.form["txt_uname"]
    phone= request.form["txt_phone"]
    if 'txt_file' in request.files:
        file= request.files["txt_file"]
        if file.filename!='':
            file.save("I:\\Research\\research\\static\\userreg\\" + file.filename)
            filename = "/static/userreg/" + file.filename
            dbcon = Db()
            qry1 = "UPDATE userreg SET name='" + fname + lname + "',gender='" + gender + "',dob='" + dob + "',phone='" + phone + "',photo='" + filename + "',email='" + uname + "' WHERE loginid='" + str(
                session['lid']) + "'"
            rowid = dbcon.update(qry1)
            return '''<script>alert("updated");window.location='/editprofile'</script>'''
        else:
            dbcon = Db()
            qry1 = "UPDATE userreg SET name='" + fname + lname + "',gender='" + gender + "',dob='" + dob + "',phone='" + phone + "',email='" + uname + "' WHERE loginid='" + str(
                session['lid']) + "'"
            rowid = dbcon.update(qry1)
            return '''<script>alert("updated");window.location='/editprofile'</script>'''
    else:
        dbcon = Db()
        qry1 = "UPDATE userreg SET name='" + fname + lname + "',gender='" + gender + "',dob='" + dob + "',phone='" + phone + "',email='" + uname + "' WHERE loginid='" + str(
            session['lid']) + "'"
        rowid = dbcon.update(qry1)
        return '''<script>alert("updated");window.location='/editprofile'</script>'''


@app.route('/changepwd')
def changepwd():
    return render_template('changepassword.html')
@app.route('/change',methods=['POST'])
def change():
    pwd=request.form["txt_password"]
    npswd=request.form["txt_newpwd"]
    cpswd=request.form["txt_conpwd"]
    dbcon = Db()
    qry = "SELECT * FROM login WHERE loginid='"+str(session['lid'])+"' and password='"+pwd+"'"
    res = dbcon.selectOne(qry)
    if res is not None:
        qry1="UPDATE login SET password='"+npswd+"' WHERE loginid='"+str(session['lid'])+"'"
        dbcon.update(qry1)
        return "<script>alert('succesfull updated');window.location='/login'</script>"
    else:
        return "<script>alert('cannot upload');window.location='/login'</script>"
    return render_template('userpanel.html')


@app.route('/adminview')
def adminview():
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:]
    return render_template('adminviewpima.html',x=x)

@app.route('/adminviewobes')
def adminviewobes():
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:]
    return render_template('adminviewobesit.html',x=x)


@app.route('/pimadataset',methods=['GET','POST'])
def pimadataset():
    return render_template('pimatraining.html',data="load")


@app.route('/lstmtraining')
def lstmtraining():
    import pandas
    from keras.models import Sequential
    from keras.layers import Dense
    from keras.callbacks import ModelCheckpoint

    seed = 42
    np.random.seed(seed)


    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]

    from sklearn.model_selection import train_test_split
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)

    NB_EPOCHS = 100  # num of epochs to test for
    BATCH_SIZE = 16

    ## Create our model
    model = Sequential()

    # 1st layer: input_dim=8, 12 nodes, RELU
    model.add(Dense(12, input_dim=8, init='uniform', activation='relu'))
    # 2nd layer: 8 nodes, RELU
    model.add(Dense(8, init='uniform', activation='relu'))
    # output layer: dim=1, activation sigmoid
    model.add(Dense(1, init='uniform', activation='sigmoid'))

    # Compile the model
    model.compile(loss='binary_crossentropy',  # since we are predicting 0/1
                  optimizer='adam',
                  metrics=['accuracy'])

    # checkpoint: store the best model
    ckpt_model = 'pima-weights.best.hdf5'
    checkpoint = ModelCheckpoint(ckpt_model,
                                 monitor='val_acc',
                                 verbose=1,
                                 save_best_only=True,
                                 mode='max')
    callbacks_list = [checkpoint]

    print('Starting training...')
    # train the model, store the results for plotting
    history = model.fit(x_train,
                        y_train,
                        validation_data=(x_test, y_test),
                        nb_epoch=NB_EPOCHS,
                        batch_size=BATCH_SIZE,
                        callbacks=callbacks_list,
                        verbose=0)

    import matplotlib.pyplot as plt
    plt.cla()
    plt.plot(history.history['acc'])
    plt.plot(history.history['val_acc'])
    plt.title('Model Accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'])

    plt.savefig("I:\\Research\\research\\static\\lik.png")

    return render_template("lstmtraining.html")


@app.route('/pima',methods=['POST'])
def pima():
    import pandas

    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]

    from sklearn.model_selection import train_test_split
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
    x_trainlen = len(x_train)
    x_testlen = len(x_test)
    x_len = len(x)

    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x_train, y_train)
    predicted = Rclass.predict(x_test)

    sk = Rclass.feature_importances_

    print(sk, "hurraaaai")
    colnames = ["Pregnancies", "Glucose", "Blood Pressure", "Skin Thickness", "Insulin", "BMI", "Diabetic Pedigree",
                "Age"]
    al=request.form["txt_algo"]
    if al=="RF":
        import pandas
        str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
        pd = pandas.read_csv(str)
        x = pd.values[0:, 0:-1]
        y = pd.values[0:, -1]
        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen=len(x_train)
        x_testlen=len(x_test)
        x_len=len(x)

        from sklearn.ensemble import RandomForestClassifier
        Rclass = RandomForestClassifier()
        Rclass.fit(x_train, y_train)
        predicted = Rclass.predict(x_test)


        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)
        print(a)

    elif al=="DT":
        import pandas
        str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
        pd = pandas.read_csv(str)
        x = pd.values[0:, 0:-1]
        y = pd.values[0:, -1]


        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)


        from sklearn.tree import DecisionTreeClassifier
        gaussian = DecisionTreeClassifier()
        gaussian.fit(x_train, y_train)
        predicted = gaussian.predict(x_test)


        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)
        print(a)


    elif al=="SVM":
        import pandas
        str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
        pd = pandas.read_csv(str)
        x = pd.values[0:, 0:-1]
        y = pd.values[0:, -1]


        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)

        from sklearn.svm import SVC
        gaussian = SVC()
        gaussian.fit(x_train, y_train)
        predicted = gaussian.predict(x_test)

        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)

    elif al=="BA":
        import pandas
        str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
        pd = pandas.read_csv(str)
        x = pd.values[0:, 0:-1]
        y = pd.values[0:, -1]

        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)

        from sklearn.ensemble import GradientBoostingClassifier
        gaussian = GradientBoostingClassifier()
        gaussian.fit(x_train, y_train)
        predicted = gaussian.predict(x_test)


        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)

    elif al=="NB":
        import pandas
        str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
        pd = pandas.read_csv(str)
        x = pd.values[0:, 0:-1]
        y = pd.values[0:, -1]

        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)

        from sklearn.naive_bayes import GaussianNB
        gaussian = GaussianNB()
        gaussian.fit(x_train, y_train)


        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)
        print(a)


    return render_template('pimatraining.html',a=a,c=c,x_trainlen=x_trainlen,x_testlen=x_testlen,x_len=x_len,al=al,sk=sk,lsk=len(sk),colnames=colnames)


@app.route('/obesitydataset',methods=['GET','POST'])
def obesitydataset():
    return render_template('obesitytraining.html',data="load")
@app.route('/obes',methods=['POST'])
def obes():
    bl = request.form["txt_algo"]
    if bl=="RF":
        import pandas
        str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
        pd = pandas.read_csv(str)
        pd["Gender"]=pd["Gender"].replace("Male",0)
        pd["Gender"] = pd["Gender"].replace("Female",1)
        yes=1
        no=0
        Sometimes=1
        Frequently=2
        Always=3
        Bike=0
        Public_Transportation=1
        Walking=2
        Automobile=3
        Motorbike=4
        pd["family_history_with_overweight"]=pd["family_history_with_overweight"].replace("yes",yes)
        pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
        pd["FAVC"]=pd["FAVC"].replace("yes",yes)
        pd["FAVC"]= pd["FAVC"].replace("no", no)
        pd["SMOKE"]=pd["SMOKE"].replace("yes",yes)
        pd["SMOKE"]=pd["SMOKE"].replace("no", no)
        pd["SCC"]=pd["SCC"].replace("yes",yes)
        pd["SCC"] =pd["SCC"].replace("no",no)
        pd["CAEC"] = pd["CAEC"].replace("no", 0)
        pd["CAEC"]=pd["CAEC"].replace("Sometimes",1)
        pd["CAEC"] = pd["CAEC"].replace("Frequently",2)
        pd["CAEC"] = pd["CAEC"].replace("Always",3)
        pd["CALC"] = pd["CALC"].replace("no", 0)
        pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
        pd["CALC"] = pd["CALC"].replace("Frequently", 2)
        pd["CALC"] = pd["CALC"].replace("Always", 3)
        pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
        pd["MTRANS"]=pd["MTRANS"].replace("Public_Transportation",1)
        pd["MTRANS"] = pd["MTRANS"].replace("Walking",2)
        pd["MTRANS"] = pd["MTRANS"].replace("Automobile",3)
        pd["MTRANS"] = pd["MTRANS"].replace("Motorbike",4)
        x = pd.values[0:, 0:-1]
        for i in x:
            print(i)
        y = pd.values[0:, -1]


        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)

        from sklearn.ensemble import RandomForestClassifier
        Rclass = RandomForestClassifier()
        Rclass.fit(x_train, y_train)
        predicted = Rclass.predict(x_test)

        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)
        print(a)
        return render_template('obesitytraining.html',a=a,c=c,x_trainlen=x_trainlen,x_testlen=x_testlen,x_len=x_len,bl=bl)


    elif bl=="NB":
        import pandas
        str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
        pd = pandas.read_csv(str)
        pd["Gender"] = pd["Gender"].replace("Male", 0)
        pd["Gender"] = pd["Gender"].replace("Female", 1)
        yes = 1
        no = 0
        Sometimes = 1
        Frequently = 2
        Always = 3
        Bike = 0
        Public_Transportation = 1
        Walking = 2
        Automobile = 3
        Motorbike = 4
        pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
        pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
        pd["FAVC"] = pd["FAVC"].replace("yes", yes)
        pd["FAVC"] = pd["FAVC"].replace("no", no)
        pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
        pd["SMOKE"] = pd["SMOKE"].replace("no", no)
        pd["SCC"] = pd["SCC"].replace("yes", yes)
        pd["SCC"] = pd["SCC"].replace("no", no)
        pd["CAEC"] = pd["CAEC"].replace("no", 0)
        pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
        pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
        pd["CAEC"] = pd["CAEC"].replace("Always", 3)
        pd["CALC"] = pd["CALC"].replace("no", 0)
        pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
        pd["CALC"] = pd["CALC"].replace("Frequently", 2)
        pd["CALC"] = pd["CALC"].replace("Always", 3)
        pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
        pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
        pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
        pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
        pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)

        x = pd.values[0:, 0:-1]
        for i in x:
            print(i)
        y = pd.values[0:, -1]

        from sklearn.model_selection import train_test_split
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=0)
        x_trainlen = len(x_train)
        x_testlen = len(x_test)
        x_len = len(x)

        from sklearn.naive_bayes import GaussianNB
        gaussian = GaussianNB()
        gaussian.fit(x_train, y_train)
        predicted = gaussian.predict(x_test)

        from sklearn.metrics import confusion_matrix
        c = confusion_matrix(y_test, predicted)
        print(c)

        from sklearn.metrics import accuracy_score
        a = accuracy_score(y_test, predicted)
        print(a)
        return render_template('obesitytraining.html',a=a,c=c,x_trainlen=x_trainlen,x_testlen=x_testlen,x_len=x_len,bl=bl)
    return render_template('obesitytraining.html')



@app.route('/predictiondiabetes')
def predictiondiabetes():
    return render_template('prediction.html')
@app.route('/predictpage',methods=['POST'])
def predictpage():
    preg=float(request.form["txt_preg"])
    glu=float(request.form["txt_glu"])
    blood=float(request.form["txt_blood"])
    skin= float(request.form["txt_skin"])
    insu= float(request.form["txt_insulin"])
    bmi= float(request.form["txt_BMI"])
    diab= float(request.form["txt_diabetic"])
    age= float(request.form["txt_age"])

    l=[[preg,glu,blood,skin,insu,bmi,diab,age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]

    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(l)
    if (predicted[0] ==0):
        predicted="Normal"
    else:
        predicted="Diabetic"

    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict= gaussian.predict(l)
    if (predict[0] ==0):
        predict="Normal"
    else:
        predict="Diabetic"
    from sklearn.tree import DecisionTreeClassifier
    dtree = DecisionTreeClassifier()
    dtree.fit(x, y)
    predictdt = dtree.predict(l)
    if (predictdt[0] ==0):
        predictdt="Normal"
    else:
        predictdt="Diabetic"
    from sklearn.ensemble import AdaBoostClassifier
    adaboost=AdaBoostClassifier()
    adaboost.fit(x, y)
    prdadaboost=adaboost.predict(l)
    if (prdadaboost[0] ==0):
        prdadaboost="Normal"
    else:
        prdadaboost="Diabetic"
    from sklearn.svm import SVC
    svm=SVC()
    svm.fit(x, y)
    prdsvm=svm.predict(l)
    if (prdsvm[0] == 0):
        prdsvm = "Normal"
    else:
        prdsvm = "Diabetic"
    return render_template('prediction.html',predicted=predicted,predict=predict,predictdt=predictdt,prdadaboost=prdadaboost,prdsvm=prdsvm)

@app.route('/predictionobesity')
def predictionobesity():
    return render_template('obesprediction.html')
@app.route('/obespredict',methods=['POST'])
def obespredict():
    Gender = float(request.form["txt_gen"])
    Age= float(request.form["txt_age"])
    Height= float(request.form["txt_heig"])
    Weight= float(request.form["txt_weig"])
    family_history= float(request.form["txt_fmh"])
    FAVC= float(request.form["txt_favc"])
    FCVC= float(request.form["txt_fcvc"])
    NCP= float(request.form["txt_ncp"])
    CAEC= float(request.form["txt_caec"])
    SMOKE= float(request.form["txt_smoke"])
    CH2O= float(request.form["txt_ch2o"])
    SCC= float(request.form["txt_scc"])
    FAF= float(request.form["txt_faf"])
    TUE= float(request.form["txt_tue"])
    CALC= float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    l=[[Gender,Age,Height,Weight,family_history,FAVC,FCVC,NCP,CAEC,SMOKE,CH2O,SCC,FAF,TUE,CALC,MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]

    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(l)
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(l)
    from sklearn.tree import DecisionTreeClassifier
    dtree = DecisionTreeClassifier()
    dtree.fit(x, y)
    predictdt = dtree.predict(l)
    from sklearn.ensemble import AdaBoostClassifier
    adaboost = AdaBoostClassifier()
    adaboost.fit(x, y)
    prdadaboost = adaboost.predict(l)
    from sklearn.svm import SVC
    svm = SVC()
    svm.fit(x, y)
    prdsvm = svm.predict(l)
    return render_template('obesprediction.html',predicted=predicted,predict=predict,predictdt=predictdt,prdadaboost=prdadaboost,prdsvm=prdsvm)


@app.route('/admin')
def admin():
    return render_template('adminpanel.html')


@app.route('/sample')
def sample():
    str="I:\\Research\\research\\static\\weatherHistory.csv"
    pd=pandas.read_csv(str)
    x=pd.values[0:10,0:3]
    return render_template('test.html',x=x)

@app.route('/index')
def index():
    return render_template('index.html')


@app.route('/userdiabetics')
def userdiabetics():
    return render_template('user_dia_prediction.html')
@app.route('/user_diapredict',methods=['POST'])
def user_diapredict():
    preg=float(request.form["txt_preg"])
    glu=float(request.form["txt_glu"])
    blood=float(request.form["txt_blood"])
    skin= float(request.form["txt_skin"])
    insu= float(request.form["txt_insulin"])
    bmi= float(request.form["txt_BMI"])
    diab= float(request.form["txt_diabetic"])
    age= float(request.form["txt_age"])

    l=[[preg,glu,blood,skin,insu,bmi,diab,age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]
    if (predicted[0] ==0):
        predicted="Normal"
    else:
        predicted="Diabetic"
    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(l)
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict= gaussian.predict(l)
    from sklearn.tree import DecisionTreeClassifier
    dtree=DecisionTreeClassifier()
    dtree.fit(x,y)
    predictdt=dtree.predict(l)
    from sklearn.ensemble import AdaBoostClassifier
    adaboost = AdaBoostClassifier()
    adaboost.fit(x, y)
    prdadaboost = adaboost.predict(l)
    from sklearn.svm import SVC
    svm = SVC()
    svm.fit(x, y)
    prdsvm = svm.predict(l)
    return render_template('user_dia_prediction.html',predicted=predicted,predict=predict,predictdt=predictdt,prdadaboost=prdadaboost,prdsvm=prdsvm)



@app.route('/userobesit')
def userobesit():
    return render_template('user_obesit_prediction.html')
@app.route('/user_obespredict',methods=['POST'])
def user_obespredict():
    Gender = float(request.form["txt_gen"])
    Age= float(request.form["txt_age"])
    Height= float(request.form["txt_heig"])
    Weight= float(request.form["txt_weig"])
    family_history= float(request.form["txt_fmh"])
    FAVC= float(request.form["txt_favc"])
    FCVC= float(request.form["txt_fcvc"])
    NCP= float(request.form["txt_ncp"])
    CAEC= float(request.form["txt_caec"])
    SMOKE= float(request.form["txt_smoke"])
    CH2O= float(request.form["txt_ch2o"])
    SCC= float(request.form["txt_scc"])
    FAF= float(request.form["txt_faf"])
    TUE= float(request.form["txt_tue"])
    CALC= float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    l=[[Gender,Age,Height,Weight,family_history,FAVC,FCVC,NCP,CAEC,SMOKE,CH2O,SCC,FAF,TUE,CALC,MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]

    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(l)
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(l)
    from sklearn.tree import DecisionTreeClassifier
    dtree = DecisionTreeClassifier()
    dtree.fit(x, y)
    predictdt = dtree.predict(l)
    from sklearn.ensemble import AdaBoostClassifier
    adaboost = AdaBoostClassifier()
    adaboost.fit(x, y)
    prdadaboost = adaboost.predict(l)
    from sklearn.svm import SVC
    svm = SVC()
    svm.fit(x, y)
    prdsvm = svm.predict(l)
    return render_template('user_obesit_prediction.html',predicted=predicted,predict=predict,predictdt=predictdt,prdadaboost=prdadaboost,prdsvm=prdsvm)



@app.route('/random_dia_obes_prediction')
def random_dia_obes_prediction():
    return render_template('total_prediction.html')
@app.route('/total_predict',methods=['POST'])
def total_predict():
    preg = float(request.form["txt_preg"])
    glu = float(request.form["txt_glu"])
    blood = float(request.form["txt_blood"])
    skin = float(request.form["txt_skin"])
    insu = float(request.form["txt_insulin"])
    diab = float(request.form["txt_diabetic"])
    age = float(request.form["txt_age"])
    Gender = float(request.form["txt_gen"])
    Height = float(request.form["txt_heig"])
    Weight = float(request.form["txt_weig"])
    family_history = float(request.form["txt_fmh"])
    FAVC = float(request.form["txt_favc"])
    FCVC = float(request.form["txt_fcvc"])
    NCP = float(request.form["txt_ncp"])
    CAEC = float(request.form["txt_caec"])
    SMOKE = float(request.form["txt_smoke"])
    CH2O = float(request.form["txt_ch2o"])
    SCC = float(request.form["txt_scc"])
    FAF = float(request.form["txt_faf"])
    TUE = float(request.form["txt_tue"])
    CALC = float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    Normal_Weight=21.5
    Over_weight_Level_1=26.25
    Over_weight_Level_11=28.75
    Obesity_Type_1=32.5
    Obesity_Type_11=37.5
    Obesity_Type_111=45
    Insufficient_Weight=8.5
    test=[[Gender,age,Height,Weight,family_history,FAVC,FCVC,NCP,CAEC,SMOKE,CH2O,SCC,FAF,TUE,CALC,MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]
    # print(x)
    # print(y)
    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(test)
    print(predicted[0])
    bmicalculated=0
    if(predicted[0]=='Normal_Weight'):
        bmicalculated=21.5
    elif(predicted[0]=='Over_weight_Level_1'):
        bmicalculated=26.25
    elif (predicted[0] == 'Over_weight_Level_11'):
        bmicalculated = 28.75
    elif (predicted[0] == 'Obesity_Type_1'):
        bmicalculated = 32.5
    elif (predicted[0] == 'Obesity_Type_11'):
        bmicalculated = 37.5
    elif (predicted[0] == 'Obesity_Type_111'):
        bmicalculated = 45
    else:
        bmicalculated = 8.5
    test1=[[preg,glu,blood,skin,insu,bmicalculated,diab,age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]
    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(test1)
    print(predicted[0])
    return render_template('total_prediction.html',predicted=predicted)


@app.route('/naive_dia_obes_prediction')
def naive_dia_obes_prediction():
    return render_template('naive_total_prediction.html')
@app.route('/naive_total_predict',methods=['POST'])
def naive_total_predict():
    preg = float(request.form["txt_preg"])
    glu = float(request.form["txt_glu"])
    blood = float(request.form["txt_blood"])
    skin = float(request.form["txt_skin"])
    insu = float(request.form["txt_insulin"])
    diab = float(request.form["txt_diabetic"])
    age = float(request.form["txt_age"])
    Gender = float(request.form["txt_gen"])
    Height = float(request.form["txt_heig"])
    Weight = float(request.form["txt_weig"])
    family_history = float(request.form["txt_fmh"])
    FAVC = float(request.form["txt_favc"])
    FCVC = float(request.form["txt_fcvc"])
    NCP = float(request.form["txt_ncp"])
    CAEC = float(request.form["txt_caec"])
    SMOKE = float(request.form["txt_smoke"])
    CH2O = float(request.form["txt_ch2o"])
    SCC = float(request.form["txt_scc"])
    FAF = float(request.form["txt_faf"])
    TUE = float(request.form["txt_tue"])
    CALC = float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    Normal_Weight=21.5
    Over_weight_Level_1=26.25
    Over_weight_Level_11=28.75
    Obesity_Type_1=32.5
    Obesity_Type_11=37.5
    Obesity_Type_111=45
    Insufficient_Weight=8.5
    test=[[Gender,age,Height,Weight,family_history,FAVC,FCVC,NCP,CAEC,SMOKE,CH2O,SCC,FAF,TUE,CALC,MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]
    # print(x)
    # print(y)
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(test)
    print(predict[0])
    bmicalculated=0
    if(predict[0]=='Normal_Weight'):
        bmicalculated=21.5
    elif(predict[0]=='Over_weight_Level_1'):
        bmicalculated=26.25
    elif (predict[0] == 'Over_weight_Level_11'):
        bmicalculated = 28.75
    elif (predict[0] == 'Obesity_Type_1'):
        bmicalculated = 32.5
    elif (predict[0] == 'Obesity_Type_11'):
        bmicalculated = 37.5
    elif (predict[0] == 'Obesity_Type_111'):
        bmicalculated = 45
    else:
        bmicalculated = 8.5
    test1=[[preg,glu,blood,skin,insu,bmicalculated,diab,age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(test1)
    print(predict[0])
    return render_template('naive_total_prediction.html',predict=predict)


@app.route('/random_user_dia_obes_prediction')
def random_user_dia_obes_prediction():
    return render_template('user_total_prediction.html')
@app.route('/random_user_total_predict',methods=['POST'])
def random_user_total_predict():
    preg = float(request.form["txt_preg"])
    glu = float(request.form["txt_glu"])
    blood = float(request.form["txt_blood"])
    skin = float(request.form["txt_skin"])
    insu = float(request.form["txt_insulin"])
    bmi = float(request.form["txt_BMI"])
    diab = float(request.form["txt_diabetic"])
    age = float(request.form["txt_age"])
    Gender = float(request.form["txt_gen"])
    Height = float(request.form["txt_heig"])
    Weight = float(request.form["txt_weig"])
    family_history = float(request.form["txt_fmh"])
    FAVC = float(request.form["txt_favc"])
    FCVC = float(request.form["txt_fcvc"])
    NCP = float(request.form["txt_ncp"])
    CAEC = float(request.form["txt_caec"])
    SMOKE = float(request.form["txt_smoke"])
    CH2O = float(request.form["txt_ch2o"])
    SCC = float(request.form["txt_scc"])
    FAF = float(request.form["txt_faf"])
    TUE = float(request.form["txt_tue"])
    CALC = float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    Normal_Weight = 21.5
    Over_weight_Level_1 = 26.25
    Over_weight_Level_11 = 28.75
    Obesity_Type_1 = 32.5
    Obesity_Type_11 = 37.5
    Obesity_Type_111 = 45
    Insufficient_Weight = 8.5
    test = [
        [Gender, age, Height, Weight, family_history, FAVC, FCVC, NCP, CAEC, SMOKE, CH2O, SCC, FAF, TUE, CALC, MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]
    # print(x)
    # print(y)
    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(test)
    print(predicted[0])
    bmicalculated = 0
    if (predicted[0] == 'Normal_Weight'):
        bmicalculated = 21.5
    elif (predicted[0] == 'Over_weight_Level_1'):
        bmicalculated = 26.25
    elif (predicted[0] == 'Over_weight_Level_11'):
        bmicalculated = 28.75
    elif (predicted[0] == 'Obesity_Type_1'):
        bmicalculated = 32.5
    elif (predicted[0] == 'Obesity_Type_11'):
        bmicalculated = 37.5
    elif (predicted[0] == 'Obesity_Type_111'):
        bmicalculated = 45
    else:
        bmicalculated = 8.5
    test1 = [[preg, glu, blood, skin, insu, bmicalculated, diab, age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]
    from sklearn.ensemble import RandomForestClassifier
    Rclass = RandomForestClassifier()
    Rclass.fit(x, y)
    predicted = Rclass.predict(test1)
    print(predicted[0])
    return render_template('user_total_prediction.html',predicted=predicted)

@app.route('/naive_user_dia_obes_prediction')
def naive_user_dia_obes_prediction():
    return render_template('naive_user_total_prediction.html',predicted="0")
@app.route('/naive_user_total_predict',methods=['POST'])
def naive_user_total_predict():
    preg = float(request.form["txt_preg"])
    glu = float(request.form["txt_glu"])
    blood = float(request.form["txt_blood"])
    skin = float(request.form["txt_skin"])
    insu = float(request.form["txt_insulin"])
    diab = float(request.form["txt_diabetic"])
    age = float(request.form["txt_age"])
    Gender = float(request.form["txt_gen"])
    Height = float(request.form["txt_heig"])
    Weight = float(request.form["txt_weig"])
    family_history = float(request.form["txt_fmh"])
    FAVC = float(request.form["txt_favc"])
    FCVC = float(request.form["txt_fcvc"])
    NCP = float(request.form["txt_ncp"])
    CAEC = float(request.form["txt_caec"])
    SMOKE = float(request.form["txt_smoke"])
    CH2O = float(request.form["txt_ch2o"])
    SCC = float(request.form["txt_scc"])
    FAF = float(request.form["txt_faf"])
    TUE = float(request.form["txt_tue"])
    CALC = float(request.form["txt_calc"])
    MTRANS = float(request.form["txt_mtrans"])
    Normal_Weight=21.5
    Over_weight_Level_1=26.25
    Over_weight_Level_11=28.75
    Obesity_Type_1=32.5
    Obesity_Type_11=37.5
    Obesity_Type_111=45
    Insufficient_Weight=8.5
    test=[[Gender,age,Height,Weight,family_history,FAVC,FCVC,NCP,CAEC,SMOKE,CH2O,SCC,FAF,TUE,CALC,MTRANS]]
    import pandas
    str = "I:\\Research\\research\\static\\ObesityDataSet_raw_and_data_sinthetic (1).csv"
    pd = pandas.read_csv(str)
    pd["Gender"] = pd["Gender"].replace("Male", 0)
    pd["Gender"] = pd["Gender"].replace("Female", 1)
    yes = 1
    no = 0
    Sometimes = 1
    Frequently = 2
    Always = 3
    Bike = 0
    Public_Transportation = 1
    Walking = 2
    Automobile = 3
    Motorbike = 4
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("yes", yes)
    pd["family_history_with_overweight"] = pd["family_history_with_overweight"].replace("no", no)
    pd["FAVC"] = pd["FAVC"].replace("yes", yes)
    pd["FAVC"] = pd["FAVC"].replace("no", no)
    pd["SMOKE"] = pd["SMOKE"].replace("yes", yes)
    pd["SMOKE"] = pd["SMOKE"].replace("no", no)
    pd["SCC"] = pd["SCC"].replace("yes", yes)
    pd["SCC"] = pd["SCC"].replace("no", no)
    pd["CAEC"] = pd["CAEC"].replace("no", 0)
    pd["CAEC"] = pd["CAEC"].replace("Sometimes", 1)
    pd["CAEC"] = pd["CAEC"].replace("Frequently", 2)
    pd["CAEC"] = pd["CAEC"].replace("Always", 3)
    pd["CALC"] = pd["CALC"].replace("no", 0)
    pd["CALC"] = pd["CALC"].replace("Sometimes", 1)
    pd["CALC"] = pd["CALC"].replace("Frequently", 2)
    pd["CALC"] = pd["CALC"].replace("Always", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Bike", 0)
    pd["MTRANS"] = pd["MTRANS"].replace("Public_Transportation", 1)
    pd["MTRANS"] = pd["MTRANS"].replace("Walking", 2)
    pd["MTRANS"] = pd["MTRANS"].replace("Automobile", 3)
    pd["MTRANS"] = pd["MTRANS"].replace("Motorbike", 4)
    x = pd.values[0:, 0:-1]
    for i in x:
        print(i)
    y = pd.values[0:, -1]
    # print(x)
    # print(y)
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(test)
    print(predict[0])
    bmicalculated=0
    if(predict[0]=='Normal_Weight'):
        bmicalculated=21.5
    elif(predict[0]=='Over_weight_Level_1'):
        bmicalculated=26.25
    elif (predict[0] == 'Over_weight_Level_11'):
        bmicalculated = 28.75
    elif (predict[0] == 'Obesity_Type_1'):
        bmicalculated = 32.5
    elif (predict[0] == 'Obesity_Type_11'):
        bmicalculated = 37.5
    elif (predict[0] == 'Obesity_Type_111'):
        bmicalculated = 45
    else:
        bmicalculated = 8.5
    test1=[[preg,glu,blood,skin,insu,bmicalculated,diab,age]]
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    x = pd.values[0:, 0:-1]
    y = pd.values[0:, -1]
    from sklearn.naive_bayes import GaussianNB
    gaussian = GaussianNB()
    gaussian.fit(x, y)
    predict = gaussian.predict(test1)
    print(predict[0])
    return render_template('naive_user_total_prediction.html',predict=predict)


@app.route('/datamining')
def datamining():
    import pandas
    str = "I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    import numpy
    import numpy
    import seaborn
    col = ["Pregnancies", "Glucose", "Blood Pressure", "Skin Thickness", "Insulin", "BMI", "Diabetic Pedigree", "Age",
           "Outcome"]
    correlation = numpy.corrcoef(pd[col].values.T)
    seaborn.set(font_scale=1)
    heatmap = seaborn.heatmap(correlation, cbar=True, annot=True, square=True, yticklabels=col, xticklabels=col)
    heatmap.get_figure().savefig("I:\\Research\\research\\static\\b.jpg", dpi=200)
    c = pd.plot(x='Pregnancies', y='Glucose', style='o')
    print(type(c))
    c.get_figure().savefig("I:\\Research\\research\\static\\s.jpg", dpi=200)

    b = pd.plot(x='Pregnancies', y='Blood Pressure', style='o')
    print(type(b))
    b.get_figure().savefig("I:\\Research\\research\\static\\r.jpg", dpi=200)

    a = pd.plot(x='Pregnancies', y='Skin Thickness', style='o')
    print(type(a))
    a.get_figure().savefig("I:\\Research\\research\\static\\p.jpg", dpi=200)

    d = pd.plot(x='Pregnancies', y='Insulin', style='o')
    print(type(d))
    d.get_figure().savefig("I:\\Research\\research\\static\\a.jpg", dpi=200)

    e = pd.plot(x='Pregnancies', y='BMI', style='o')
    print(type(e))
    e.get_figure().savefig("I:\\Research\\research\\static\\c.jpg", dpi=200)

    f = pd.plot(x='Pregnancies', y='Diabetic Pedigree', style='o')
    print(type(f))
    f.get_figure().savefig("I:\\Research\\research\\static\\d.jpg", dpi=200)

    g = pd.plot(x='Pregnancies', y='Age', style='o')
    print(type(g))
    g.get_figure().savefig("I:\\Research\\research\\static\\e.jpg", dpi=200)

    h = pd.plot(x='Pregnancies', y='Outcome', style='o')
    print(type(h))
    h.get_figure().savefig("I:\\Research\\research\\static\\f.jpg", dpi=200)

    i = pd.plot(x='Glucose', y='Blood Pressure', style='o')
    print(type(i))
    i.get_figure().savefig("I:\\Research\\research\\static\\g.jpg", dpi=200)

    j = pd.plot(x='Glucose', y='Skin Thickness', style='o')
    print(type(j))
    j.get_figure().savefig("I:\\Research\\research\\static\\.jpg", dpi=200)

    k = pd.plot(x='Glucose', y='Insulin', style='o')
    print(type(k))
    k.get_figure().savefig("I:\\Research\\research\\static\\i.jpg", dpi=200)

    l = pd.plot(x='Glucose', y='BMI', style='o')
    print(type(l))
    l.get_figure().savefig("I:\\Research\\research\\static\\j.jpg", dpi=200)

    m = pd.plot(x='Glucose', y='Diabetic Pedigree', style='o')
    print(type(m))
    m.get_figure().savefig("I:\\Research\\research\\static\\k.jpg", dpi=200)

    n = pd.plot(x='Glucose', y='Age', style='o')
    print(type(n))
    n.get_figure().savefig("I:\\Research\\research\\static\\l.jpg", dpi=200)

    o = pd.plot(x='Glucose', y='Outcome', style='o')
    print(type(o))
    o.get_figure().savefig("I:\\Research\\research\\static\\m.jpg", dpi=200)

    p = pd.plot(x='Blood Pressure', y='Skin Thickness', style='o')
    print(type(p))
    p.get_figure().savefig("I:\\Research\\research\\static\\n.jpg", dpi=200)

    q = pd.plot(x='Blood Pressure', y='Insulin', style='o')
    print(type(q))
    q.get_figure().savefig("I:\\Research\\research\\static\\o.jpg", dpi=200)

    r = pd.plot(x='Blood Pressure', y='BMI', style='o')
    print(type(r))
    r.get_figure().savefig("I:\\Research\\research\\static\\ap.jpg", dpi=200)

    s = pd.plot(x='Blood Pressure', y='Diabetic Pedigree', style='o')
    print(type(s))
    s.get_figure().savefig("I:\\Research\\research\\static\\q.jpg", dpi=200)

    t = pd.plot(x='Blood Pressure', y='Age', style='o')
    print(type(t))
    t.get_figure().savefig("I:\\Research\\research\\static\\ar.jpg", dpi=200)

    u = pd.plot(x='Blood Pressure', y='Outcome', style='o')
    print(type(u))
    u.get_figure().savefig("I:\\Research\\research\\static\\s.jpg", dpi=200)

    v = pd.plot(x='Skin Thickness', y='Insulin', style='o')
    print(type(v))
    v.get_figure().savefig("I:\\Research\\research\\static\\t.jpg", dpi=200)

    w = pd.plot(x='Skin Thickness', y='BMI', style='o')
    print(type(w))
    w.get_figure().savefig("I:\\Research\\research\\static\\u.jpg", dpi=200)

    x = pd.plot(x='Skin Thickness', y='Diabetic Pedigree', style='o')
    print(type(x))
    x.get_figure().savefig("I:\\Research\\research\\static\\v.jpg", dpi=200)

    y = pd.plot(x='Skin Thickness', y='Age', style='o')
    print(type(y))
    y.get_figure().savefig("I:\\Research\\research\\static\\w.jpg", dpi=200)

    ab = pd.plot(x='Skin Thickness', y='Outcome', style='o')
    print(type(ab))
    ab.get_figure().savefig("I:\\Research\\research\\static\\y.jpg", dpi=200)

    ac = pd.plot(x='Insulin', y='BMI', style='o')
    print(type(ac))
    ac.get_figure().savefig("I:\\Research\\research\\static\\z.jpg", dpi=200)

    ad = pd.plot(x='Insulin', y='Diabetic Pedigree', style='o')
    print(type(ad))
    ad.get_figure().savefig("I:\\Research\\research\\static\\aa.jpg", dpi=200)

    ae = pd.plot(x='Insulin', y='Age', style='o')
    print(type(ae))
    ae.get_figure().savefig("I:\\Research\\research\\static\\bb.jpg", dpi=200)

    af = pd.plot(x='Insulin', y='Outcome', style='o')
    print(type(af))
    af.get_figure().savefig("I:\\Research\\research\\static\\cc.jpg", dpi=200)

    af = pd.plot(x='BMI', y='Diabetic Pedigree', style='o')
    print(type(af))
    af.get_figure().savefig("I:\\Research\\research\\static\\dd.jpg", dpi=200)

    ag = pd.plot(x='BMI', y='Age', style='o')
    print(type(ag))
    ag.get_figure().savefig("I:\\Research\\research\\static\\\ee.jpg", dpi=200)

    ah = pd.plot(x='BMI', y='Outcome', style='o')
    print(type(ah))
    ah.get_figure().savefig("I:\\Research\\research\\static\\ff.jpg", dpi=200)

    ai = pd.plot(x='Diabetic Pedigree', y='Age', style='o')
    print(type(ai))
    ai.get_figure().savefig("I:\\Research\\research\\static\\gg.jpg", dpi=200)

    aj = pd.plot(x='Diabetic Pedigree', y='Outcome', style='o')
    print(type(aj))
    aj.get_figure().savefig("I:\\Research\\research\\static\\hh.jpg", dpi=200)

    ak = pd.plot(x='Age', y='Outcome', style='o')
    print(type(ak))
    ak.get_figure().savefig("I:\\Research\\research\\static\\ii.jpg", dpi=200)
    return render_template('pima_datamining.html')


@app.route('/user_datamining')
def user_datamining():
    import pandas
    # str = "E:\\pythonProject\\research\\static\\pima-indians-diabetes.csv"
    str ="I:\\Research\\research\\static\\pima-indians-diabetes.csv"
    pd = pandas.read_csv(str)
    import numpy
    import numpy
    import seaborn
    col = ["Pregnancies", "Glucose", "Blood Pressure", "Skin Thickness", "Insulin", "BMI", "Diabetic Pedigree", "Age",
           "Outcome"]
    correlation = numpy.corrcoef(pd[col].values.T)
    seaborn.set(font_scale=1)
    heatmap = seaborn.heatmap(correlation, cbar=True, annot=True, square=True, yticklabels=col, xticklabels=col)
    heatmap.get_figure().savefig("I:\\Research\\research\\static\\b.jpg", dpi=200)
    c = pd.plot(x='Pregnancies', y='Glucose', style='o')
    print(type(c))
    c.get_figure().savefig("I:\\Research\\research\\static\\s.jpg", dpi=200)

    b = pd.plot(x='Pregnancies', y='Blood Pressure', style='o')
    print(type(b))
    b.get_figure().savefig("I:\\Research\\research\\static\\r.jpg", dpi=200)

    a = pd.plot(x='Pregnancies', y='Skin Thickness', style='o')
    print(type(a))
    a.get_figure().savefig("I:\\Research\\research\\static\\p.jpg", dpi=200)

    d = pd.plot(x='Pregnancies', y='Insulin', style='o')
    print(type(d))
    d.get_figure().savefig("I:\\Research\\research\\static\\a.jpg", dpi=200)

    e = pd.plot(x='Pregnancies', y='BMI', style='o')
    print(type(e))
    e.get_figure().savefig("I:\\Research\\research\\static\\c.jpg", dpi=200)

    f = pd.plot(x='Pregnancies', y='Diabetic Pedigree', style='o')
    print(type(f))
    f.get_figure().savefig("I:\\Research\\research\\static\\d.jpg", dpi=200)

    g = pd.plot(x='Pregnancies', y='Age', style='o')
    print(type(g))
    g.get_figure().savefig("I:\\Research\\research\\static\\e.jpg", dpi=200)

    h = pd.plot(x='Pregnancies', y='Outcome', style='o')
    print(type(h))
    h.get_figure().savefig("I:\\Research\\research\\static\\f.jpg", dpi=200)

    i = pd.plot(x='Glucose', y='Blood Pressure', style='o')
    print(type(i))
    i.get_figure().savefig("I:\\Research\\research\\static\\g.jpg", dpi=200)

    j = pd.plot(x='Glucose', y='Skin Thickness', style='o')
    print(type(j))
    j.get_figure().savefig("I:\\Research\\research\\static\\h.jpg", dpi=200)

    k = pd.plot(x='Glucose', y='Insulin', style='o')
    print(type(k))
    k.get_figure().savefig("I:\\Research\\research\\static\\i.jpg", dpi=200)

    l = pd.plot(x='Glucose', y='BMI', style='o')
    print(type(l))
    l.get_figure().savefig("I:\\Research\\research\\static\\j.jpg", dpi=200)

    m = pd.plot(x='Glucose', y='Diabetic Pedigree', style='o')
    print(type(m))
    m.get_figure().savefig("I:\\Research\\research\\static\\k.jpg", dpi=200)

    n = pd.plot(x='Glucose', y='Age', style='o')
    print(type(n))
    n.get_figure().savefig("I:\\Research\\research\\static\\l.jpg", dpi=200)

    o = pd.plot(x='Glucose', y='Outcome', style='o')
    print(type(o))
    o.get_figure().savefig("I:\\Research\\research\\static\\m.jpg", dpi=200)

    p = pd.plot(x='Blood Pressure', y='Skin Thickness', style='o')
    print(type(p))
    p.get_figure().savefig("I:\\Research\\research\\static\\n.jpg", dpi=200)

    q = pd.plot(x='Blood Pressure', y='Insulin', style='o')
    print(type(q))
    q.get_figure().savefig("I:\\Research\\research\\static\\o.jpg", dpi=200)

    r = pd.plot(x='Blood Pressure', y='BMI', style='o')
    print(type(r))
    r.get_figure().savefig("I:\\Research\\research\\static\\ap.jpg", dpi=200)

    s = pd.plot(x='Blood Pressure', y='Diabetic Pedigree', style='o')
    print(type(s))
    s.get_figure().savefig("I:\\Research\\research\\static\\q.jpg", dpi=200)

    t = pd.plot(x='Blood Pressure', y='Age', style='o')
    print(type(t))
    t.get_figure().savefig("I:\\Research\\research\\static\\ar.jpg", dpi=200)

    u = pd.plot(x='Blood Pressure', y='Outcome', style='o')
    print(type(u))
    u.get_figure().savefig("I:\\Research\\research\\static\\as.jpg", dpi=200)

    v = pd.plot(x='Skin Thickness', y='Insulin', style='o')
    print(type(v))
    v.get_figure().savefig("I:\\Research\\research\\static\\t.jpg", dpi=200)

    w = pd.plot(x='Skin Thickness', y='BMI', style='o')
    print(type(w))
    w.get_figure().savefig("I:\\Research\\research\\static\\u.jpg", dpi=200)

    x = pd.plot(x='Skin Thickness', y='Diabetic Pedigree', style='o')
    print(type(x))
    x.get_figure().savefig("I:\\Research\\research\\static\\v.jpg", dpi=200)

    y = pd.plot(x='Skin Thickness', y='Age', style='o')
    print(type(y))
    y.get_figure().savefig("I:\\Research\\research\\static\\w.jpg", dpi=200)

    ab = pd.plot(x='Skin Thickness', y='Outcome', style='o')
    print(type(ab))
    ab.get_figure().savefig("I:\\Research\\research\\static\\y.jpg", dpi=200)

    ac = pd.plot(x='Insulin', y='BMI', style='o')
    print(type(ac))
    ac.get_figure().savefig("I:\\Research\\research\\static\\z.jpg", dpi=200)

    ad = pd.plot(x='Insulin', y='Diabetic Pedigree', style='o')
    print(type(ad))
    ad.get_figure().savefig("I:\\Research\\research\\static\\aa.jpg", dpi=200)

    ae = pd.plot(x='Insulin', y='Age', style='o')
    print(type(ae))
    ae.get_figure().savefig("I:\\Research\\research\\static\\bb.jpg", dpi=200)

    af = pd.plot(x='Insulin', y='Outcome', style='o')
    print(type(af))
    af.get_figure().savefig("I:\\Research\\research\\static\\cc.jpg", dpi=200)

    af = pd.plot(x='BMI', y='Diabetic Pedigree', style='o')
    print(type(af))
    af.get_figure().savefig("I:\\Research\\research\\static\\dd.jpg", dpi=200)

    ag = pd.plot(x='BMI', y='Age', style='o')
    print(type(ag))
    ag.get_figure().savefig("I:\\Research\\research\\static\\ee.jpg", dpi=200)

    ah = pd.plot(x='BMI', y='Outcome', style='o')
    print(type(ah))
    ah.get_figure().savefig("I:\\Research\\research\\static\\ff.jpg", dpi=200)

    ai = pd.plot(x='Diabetic Pedigree', y='Age', style='o')
    print(type(ai))
    ai.get_figure().savefig("I:\\Research\\research\\static\\gg.jpg", dpi=200)

    aj = pd.plot(x='Diabetic Pedigree', y='Outcome', style='o')
    print(type(aj))
    aj.get_figure().savefig("I:\\Research\\research\\static\\hh.jpg", dpi=200)



    ak = pd.plot(x='Age', y='Outcome', style='o')
    print(type(ak))
    ak.get_figure().savefig("I:\\Research\\research\\static\\ii.jpg", dpi=200)
    return render_template('user_pima_datamining.html')


@app.route('/log')
def log():
    return render_template('index1.html')

@app.route('/reg')
def reg():
    return render_template('index2.html')


@app.route('/ad')
def ad():
    return render_template('blank-page.html')

@app.route('/userind')
def userind():
    return render_template('userindex.html')

@app.route('/adminpanel')
def adminpanel():
    return render_template('adminpanel.html')

@app.route('/userpanel')
def userpanel():
    return render_template('userpanel.html')

@app.route('/logout')
def logout():
    return render_template('login.html')

@app.route('/admin_password')
def admin_password():
    return render_template('admin_changepwd.html')



@app.route('/doct_home')
def doct_home():
    return render_template("doctor/doct_home.html")

@app.route('/signupdoctor')
def signupdoctor():

    return render_template("doctor/signup.html")

@app.route('/signup_post', methods=['POST'])
def signup_post():
    name=request.form['textfield']
    gender=request.form['txt_gender']
    department=request.form['textfield3']
    qualification=request.form['textfield5']
    speciality=request.form['textfield4']
    hospitalname=request.form['textfield2']
    city=request.form['textfield8']
    email=request.form['textfield6']
    phone=request.form['textfield7']
    photo=request.files['fileField']
    password=request.form['pass']
    confirm=request.form['confirm']
    from datetime import datetime
    date=datetime.now().strftime('%Y%m%d-%H%M%S')
    photo.save("I:\\Research\\research\\static\\doctor\\"+date+".jpg")
    path="/static/doctor/"+date+".jpg"
    dbcon=Db()
    qry="INSERT INTO `login`(`username`.`password`.`usertype`)VALUES('"+email+"','"+confirm+"','doctor')"
    res=dbcon.insert(qry)
    qry2="INSERT INTO `doctor`(`loginid`,`doc_name`,`gender`,`department`,`qualification`,`speciality`,`hos_name`,`email`,`city`,`photo`,`phone`,`status`)" \
         "VALUES('"+str(res)+"','"+name+"','"+gender+"','"+department+"','"+qualification+"','"+speciality+"','"+hospitalname+"','"+email+"','"+city+"','"+path+"','"+phone+"','pending')"
    res2=dbcon.insert(qry2)
    return '''<sctipr>alert("success");window.location='/'</script>'''

@app.route('/view_profile')
def view_profile():
    dbcon=Db()
    qry="SELECT * FROM `doctors` WHERE `loginid`='"+str(session['lid'])+"'"
    res=dbcon.selectOne(qry)
    return render_template("doctor/view_profile.html",data=res)

@app.route('/add_schedule')
def add_schedule():
    return render_template("doctor/add_schedule.html")

@app.route('/add_schedule_post', methods=['POST'])
def add_schedule_post():
    date=request.form['date']
    fromtime=request.form['fromtime']
    totime=request.form['totime']
    dbcon=Db()
    qry="INSERT INTO `schedule` (`sh_date`,`from_time`,`to_time`,`doctor_lid`) VALUES ('"+date+"','"+fromtime+"','"+totime+"','"+str(session['lid'])+"')"
    res=dbcon.insert(qry)
    return '''<script>alert("success");window.location='/add_schedule'</script>'''

@app.route('/view_schedule')
def view_schedulepost():
    db=Db()
    qry="SELECT * FROM `schedule` WHERE `doctor_lid`='"+str(session['lid'])+"'"
    res= db.select(qry)
    return render_template("doctor/view_schedule.html",data=res)

@app.route('/admin_viewdoctros')
def admin_viewdoctros():
    db=Db()
    qry="SELECT * FROM `doctors`"
    res= db.select(qry)
    return render_template("adminviewdoctors.html",data=res)

@app.route('/admin_viewdoctrossearch',methods=['post'])
def admin_viewdoctrossearch():
    search= request.form['search']
    db=Db()
    qry="SELECT * FROM `doctors` where name like '%"+search+"%'"
    res= db.select(qry)
    return render_template("adminviewdoctors.html",data=res)

@app.route('/deleteschedule/<sid>')
def deleteschedule(sid):
    db=Db()
    qry="DELETE FROM `schedule` WHERE `scheduleid`='"+sid+"'"
    db.delete(qry)
    return "<script>alert('Schedule deleted successfully');window.location='/view_schedule'</script>"



@app.route('/user_viewdoctros')
def user_viewdoctros():
    db=Db()
    qry="SELECT * FROM `doctors`"
    res= db.select(qry)
    return render_template("userviewdoctors.html",data=res)

@app.route('/user_viewdoctrossearch',methods=['post'])
def user_viewdoctrossearch():
    search= request.form['search']
    db=Db()
    qry="SELECT * FROM `doctors` where name like '%"+search+"%'"
    res= db.select(qry)
    return render_template("userviewdoctors.html",data=res)



@app.route('/user_viewdoctorschedule/<dlid>')
def user_viewdoctorschedule(dlid):
    db=Db()
    qry="SELECT * FROM `schedule` WHERE `doctor_lid`='"+dlid+"'"
    res= db.select(qry)
    return render_template("user_view_schedule.html",data=res)

####doctor part


@app.route('/doctor_signup')
def doctor_signup():
    return render_template("signupdoctor.html")




##### end doctor part






if __name__=='__main__':
    app.run(debug=True,threaded=False,port=4000)