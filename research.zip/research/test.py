import pandas
str = "E:\\pythonProject\\research\\static\\pima-indians-diabetes.csv"
pd=pandas.read_csv(str)

import numpy
import seaborn
col=["Pregnancies","Glucose","Blood Pressure","Skin Thickness","Insulin","BMI","Diabetic Pedigree","Age","Outcome"]
correlation=numpy.corrcoef(pd[col].values.T)
seaborn.set(font_scale=1)
heatmap=seaborn.heatmap(correlation,cbar=True,annot=True,square=True,yticklabels=col,xticklabels=col)
heatmap.get_figure().savefig("b.jpg",dpi=200)
c=pd.plot(x='Pregnancies',y='Glucose',style='o')
print(type(c))
c.get_figure().savefig("s.jpg",dpi=200)

b=pd.plot(x='Insulin',y='BMI',style='o')
print(type(b))
b.get_figure().savefig("r.jpg",dpi=200)

a=pd.plot(x='Glucose',y='Age',style='o')
print(type(a))
a.get_figure().savefig("p.jpg",dpi=200)

