import pandas
str = "E:\\pythonProject\\research\\static\\pima-indians-diabetes.csv"
pd = pandas.read_csv(str)
x = pd.values[0:, 0:-1]
y=pd.values[0:,-1]
#print(x)
#print(y)

from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.4,random_state=0)
#print(len(x_train))
#print(len(x_test))
#print(len(y_train))
#print(len(y_test))


from sklearn.naive_bayes import GaussianNB
gaussian=GaussianNB()
gaussian.fit(x_train,y_train)
predicted=gaussian.predict(x_test)
#print(predicted)
#print(y_test)

from sklearn.metrics import confusion_matrix
c=confusion_matrix(y_test,predicted)
print(c)

from sklearn.metrics import accuracy_score
a=accuracy_score(y_test,predicted)
print(a)